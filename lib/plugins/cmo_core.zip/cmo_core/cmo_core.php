<?php

/**
 *
 * @wordpress-plugin
 * Plugin Name:       CMO Core
 * Description:       Support plugin for CMO theme.
 * Version:           1.0.0
 * Author:            Andit Themes
 * Author URI:        https://anditthemes.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       cmo_core
 * Domain Path:       /languages
 */

require_once( __DIR__ . '/widgets/cmo-social-profile-information.php' );
require_once( __DIR__ . '/widgets/cmo-widget-recent-posts.php');
require_once( __DIR__ . '/widgets/cmo-widget-categories.php' );
require_once( __DIR__ . '/widgets/cmo-widget-tag-cloud.php' );
require_once( __DIR__ . '/widgets/cmo-widgets.php' );

 /* Custom Post */

 function cptui_register_my_cpts() {

	/**
	 * Post Type: Slider.
	*/

	$labels = array(
		"name" => __( "Slider", "cmo" ),
		"singular_name" => __( "Slider", "cmo" ),
	);

	$args = array(
		"label" => __( "Slider", "cmo" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => true,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => true,
		"rewrite" => array( "slug" => "slider", "with_front" => true ),
		"query_var" => true,
		"menu_icon" => "dashicons-slides",
		"supports" => array( "title" ),
	);

	register_post_type( "slider", $args );

	/**
	 * Post Type: Service.
	*/

	$labels = array(
		"name" => __( "Service", "cmo" ),
		"singular_name" => __( "Service", "cmo" ),
	);

	$args = array(
		"label" => __( "Service", "cmo" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "service", "with_front" => true ),
		"query_var" => true,
		"menu_icon" => "dashicons-editor-paste-word",
		"supports" => array( "title", "editor", "thumbnail", "excerpt" ),
	);

	register_post_type( "service", $args );

	/**
	 * Post Type: Portfolio.
	*/

	$labels = array(
		"name" => __( "Portfolio", "cmo" ),
		"singular_name" => __( "Portfolio", "cmo" ),
	);

	$args = array(
		"label" => __( "Portfolio", "cmo" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "portfolio", "with_front" => true ),
		"query_var" => true,
		"menu_icon" => "dashicons-portfolio",
		"supports" => array( "title", "editor", "thumbnail" ),
	);

	register_post_type( "portfolio", $args );

	/**
	 * Post Type: Testimonial.
	*/

	$labels = array(
		"name" => __( "Testimonial", "cmo" ),
		"singular_name" => __( "Testimonial", "cmo" ),
	);

	$args = array(
		"label" => __( "Testimonial", "cmo" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "testimonial", "with_front" => true ),
		"query_var" => true,
		"menu_icon" => "dashicons-testimonial",
		"supports" => array( "title" ),
	);

	register_post_type( "testimonial", $args );

	/**
	 * Post Type: Client.
	*/

	$labels = array(
		"name" => __( "Client", "cmo" ),
		"singular_name" => __( "Client", "cmo" ),
	);

	$args = array(
		"label" => __( "Client", "cmo" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "client", "with_front" => true ),
		"query_var" => true,
		"menu_icon" => "dashicons-index-card",
		"supports" => array( "title", "thumbnail" ),
	);

	register_post_type( "client", $args );

	/**
	 * Post Type: Team.
	*/

	$labels = array(
		"name" => __( "Team", "cmo" ),
		"singular_name" => __( "Team", "cmo" ),
	);

	$args = array(
		"label" => __( "Team", "cmo" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "team", "with_front" => true ),
		"query_var" => true,
		"menu_icon" => "dashicons-admin-users",
		"supports" => array( "title" ),
	);

	register_post_type( "team", $args );

	/**
	 * Post Type: Case Study.
	*/

	$labels = array(
		"name" => __( "Case Study", "cmo" ),
		"singular_name" => __( "Case Study", "cmo" ),
	);

	$args = array(
		"label" => __( "Case Study", "cmo" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "case_study", "with_front" => true ),
		"query_var" => true,
		"menu_icon" => "dashicons-media-spreadsheet",
		"supports" => array( "title", "editor", "thumbnail" ),
	);

	register_post_type( "case_study", $args );
}

add_action( 'init', 'cptui_register_my_cpts' );

/* Taxonomy */

function cptui_register_my_taxes() {

	/**
	 * Taxonomy: Service Categories.
	 */

	$labels = array(
		"name" => __( "Service Categories", "cmo" ),
		"singular_name" => __( "Service Category", "cmo" ),
	);

	$args = array(
		"label" => __( "Service Categories", "cmo" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => true,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => array( 'slug' => 'service_category', 'with_front' => true, ),
		"show_admin_column" => false,
		"show_in_rest" => true,
		"rest_base" => "service_category",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"show_in_quick_edit" => false,
		);
	register_taxonomy( "service_category", array( "service" ), $args );

	/**
	 * Taxonomy: Portfolio Categories.
	 */

	$labels = array(
		"name" => __( "Portfolio Categories", "cmo" ),
		"singular_name" => __( "Portfolio Category", "cmo" ),
	);

	$args = array(
		"label" => __( "Portfolio Categories", "cmo" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => true,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => array( 'slug' => 'portfolio_category', 'with_front' => true, ),
		"show_admin_column" => false,
		"show_in_rest" => true,
		"rest_base" => "portfolio_category",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"show_in_quick_edit" => false,
		);
	register_taxonomy( "portfolio_category", array( "portfolio" ), $args );

	/**
	 * Taxonomy: Case Study Categories.
	 */

	$labels = array(
		"name" => __( "Case Study Categories", "cmo" ),
		"singular_name" => __( "Case Study Category", "cmo" ),
	);

	$args = array(
		"label" => __( "Case Study Categories", "cmo" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => true,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => array( 'slug' => 'case_category', 'with_front' => true, ),
		"show_admin_column" => false,
		"show_in_rest" => true,
		"rest_base" => "case_category",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"show_in_quick_edit" => false,
		);
	register_taxonomy( "case_category", array( "case_study" ), $args );
}
add_action( 'init', 'cptui_register_my_taxes' );
