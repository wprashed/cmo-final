<?php
/**
 * Widget API: WP_Widget_Categories class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.4.0
 */

/**
 * Core class used to implement a Categories widget.
 *
 * @since 2.8.0
 *
 * @see WP_Widget
 */
class CMO_Widget_Categories extends WP_Widget {

	/**
	 * Sets up a new Categories widget instance.
	 *
	 * @since 2.8.0
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'                   => 'widget_categories',
			'description'                 => __( 'A list of categories.','cmo' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'categories', __( 'Categories','cmo' ), $widget_ops );
	}

	/**
	 * Outputs the content for the current Categories widget instance.
	 *
	 * @since 2.8.0
	 *
	 * @staticvar bool $first_dropdown
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Categories widget instance.
	 */
	public function widget( $args, $instance ) {
		static $first_dropdown = true;

		$title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Categories','cmo' );

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		echo wp_kses_post($args['before_widget']);

		if ( $title ) {
			echo '<div class="header">';
			echo wp_kses_post($args['before_title'] . $title . $args['after_title']);
			echo '</div>';
		}
		$categories = get_the_category();
		foreach($categories as $category):
		?>
		<div class="catg-item d-flex ">
			<div class="catg-icon">
				<i class="fa fa-dot-circle-o" aria-hidden="true"></i>
			</div>
			<!--catg-icon-->
			<p><a href="<?php echo get_category_link($category->term_id);?>"><?php echo esc_html($category->name); ?></a></p>
			<div class="catg-img">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/blog/line-1.png" class="img-responsive" alt="catg-img">
			</div>
			<!--catg-img-->
			<span><?php echo esc_html($category->count); ?></span>
        </div>
		<?php
		endforeach;
		echo wp_kses_post($args['after_widget']);
	}

	/**
	 * Handles updating settings for the current Categories widget instance.
	 *
	 * @since 2.8.0
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                 = $old_instance;
		$instance['title']        = sanitize_text_field( $new_instance['title'] );

		return $instance;
	}

	/**
	 * Outputs the settings form for the Categories widget.
	 *
	 * @since 2.8.0
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		//Defaults
		$instance = wp_parse_args( (array) $instance, array( 'title' => '') );
		$title = sanitize_text_field( $instance['title'] );
		?>
		<p><label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e( 'Title:','cmo' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></p>
		<?php
	}

}

function cmo_categories_widget() {
	register_widget('CMO_Widget_Categories');
}
add_action('widgets_init', 'cmo_categories_widget');