<?php
/**
 * Show custom user profile fields
 * 
 * @param  object $profileuser A WP_User object
 * @return void
 */
function custom_user_profile_fields($profileuser) {
    ?>
    <h3><?php _e('Social profile information','cmo');?></h3>
        <table class="form-table">
            <tr>
                <th>
                    <label for="facebook_url"><?php _e('Facebook','cmo'); ?></label>
                </th>
                <td>
                    <input type="text" name="facebook_url" id="facebook_url" value="<?php echo esc_attr( get_the_author_meta( 'facebook_url', $profileuser->ID ) ); ?>" class="regular-text" />
                    <br><span class="description"><?php _e('Your Facebook url.', 'cmo'); ?></span>
                </td>
            </tr>
            <tr>
            <th>
                    <label for="instagram_url"><?php _e('Instagram','cmo'); ?></label>
                </th>
                <td>
                    <input type="text" name="instagram_url" id="instagram_url" value="<?php echo esc_attr( get_the_author_meta( 'instagram_url', $profileuser->ID ) ); ?>" class="regular-text" />
                    <br><span class="description"><?php _e('Your Instagram url.', 'cmo'); ?></span>
                </td>
            </tr>
            <th>
                    <label for="twitter_url"><?php _e('Twitter','cmo'); ?></label>
                </th>
                <td>
                    <input type="text" name="twitter_url" id="twitter_url" value="<?php echo esc_attr( get_the_author_meta( 'twitter_url', $profileuser->ID ) ); ?>" class="regular-text" />
                    <br><span class="description"><?php _e('Your Twitter url.', 'cmo'); ?></span>
                </td>
            </tr>
            <th>
                    <label for="linkedin_url"><?php _e('Linkedin','cmo'); ?></label>
                </th>
                <td>
                    <input type="text" name="linkedin_url" id="linkedin_url" value="<?php echo esc_attr( get_the_author_meta( 'linkedin_url', $profileuser->ID ) ); ?>" class="regular-text" />
                    <br><span class="description"><?php _e('Your Linkedin url.', 'cmo'); ?></span>
                </td>
            </tr>
        </table>
    <?php
    }
    add_action('show_user_profile', 'custom_user_profile_fields', 10, 1);
    add_action('edit_user_profile', 'custom_user_profile_fields', 10, 1);

    function custom_user_register_fields($profileuser) {
        ?>
    <h3><?php _e('Social profile information','cmo');?></h3>
        <table class="form-table">
            <tr>
                <th>
                    <label for="facebook_url"><?php _e('Facebook','cmo'); ?></label>
                </th>
                <td>
                    <input type="text" name="facebook_url" id="facebook_url" value="<?php echo esc_attr( get_the_author_meta( 'facebook_url', $profileuser ) ); ?>" class="regular-text" />
                    <br><span class="description"><?php _e('Your Facebook url.', 'cmo'); ?></span>
                </td>
            </tr>
            <tr>
            <th>
                    <label for="instagram_url"><?php _e('Instagram','cmo'); ?></label>
                </th>
                <td>
                    <input type="text" name="instagram_url" id="instagram_url" value="<?php echo esc_attr( get_the_author_meta( 'instagram_url', $profileuser ) ); ?>" class="regular-text" />
                    <br><span class="description"><?php _e('Your Instagram url.', 'cmo'); ?></span>
                </td>
            </tr>
            <th>
                    <label for="twitter_url"><?php _e('Twitter','cmo'); ?></label>
                </th>
                <td>
                    <input type="text" name="twitter_url" id="twitter_url" value="<?php echo esc_attr( get_the_author_meta( 'twitter_url', $profileuser ) ); ?>" class="regular-text" />
                    <br><span class="description"><?php _e('Your Twitter url.', 'cmo'); ?></span>
                </td>
            </tr>
            <th>
                    <label for="linkedin_url"><?php _e('Linkedin','cmo'); ?></label>
                </th>
                <td>
                    <input type="text" name="linkedin_url" id="linkedin_url" value="<?php echo esc_attr( get_the_author_meta( 'linkedin_url', $profileuser ) ); ?>" class="regular-text" />
                    <br><span class="description"><?php _e('Your Linkedin url.', 'cmo'); ?></span>
                </td>
            </tr>
        </table>
        <?php
    }
    add_action( "user_new_form", "custom_user_register_fields", 10, 2 );

    //update user meta
add_action( 'personal_options_update', 'my_save_extra_profile_fields', 10, 1 );
add_action( 'edit_user_profile_update', 'my_save_extra_profile_fields', 10, 1 );
add_action( 'user_register', 'my_save_extra_profile_fields', 10, 1 );

function my_save_extra_profile_fields( $user_id ) {

	if ( !current_user_can( 'edit_user', $user_id ) )
		return false;

	/* Copy and paste this line for additional fields. Make sure to change 'facebook' to the field ID. */
    update_user_meta( $user_id, 'facebook_url', $_POST['facebook_url'] );
    update_user_meta( $user_id, 'instagram_url', $_POST['instagram_url'] );
    update_user_meta( $user_id, 'twitter_url', $_POST['twitter_url'] );
    update_user_meta( $user_id, 'linkedin_url', $_POST['linkedin_url'] );
}
?>