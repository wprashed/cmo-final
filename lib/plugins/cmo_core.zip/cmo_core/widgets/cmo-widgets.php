<?php
class cmo_contact extends WP_Widget{
	public function __construct(){
		parent::__construct('cmo_contact',__('CMO Contact','cmo'),array(
			'description' => __('this contact Widget only for single service page','cmo'),
		));
	}

	public function widget($args, $instance){
        global $cmo;
		$title = $instance['title'];
        ?>
         <!-- Contact Area Section Start -->
         <div class="contact-area">
                        <?php echo wp_kses_post($args['before_widget'].$args['before_title'].$title.$args['after_title'].$args['after_widget']); ?>
                        <div class="ca-area d-flex">
                            <div class="content-icon">
                                <i class="fa fa-home fa-2x"></i>
                            </div>
                            <div class="text-area">
                            <p>
                                <?php 
                                if(!empty($cmo['cmo-textarea']) ) {
                                   echo esc_textarea($cmo['cmo-textarea']); 
                                } 
                             ?></p>
                            </div>
                        </div>
                        <div class="ca-area d-flex">
                            <div class="content-icon">
                               <i class="fa fa-phone fa-2x"></i>
                            </div>
                            <div class="text-area">
                                <p><?php 
                                        if(!empty($cmo['header_info_phone']) ) {
                                            echo esc_html($cmo['header_info_phone']); 
                                        } 
                                    ?></p>
                            </div>
                        </div>
                        <div class="ca-area d-flex">
                            <div class="content-icon">
                                <i class="fa fa-paper-plane fa-2x"></i>
                            </div>
                            <div class="text-area">
                            <p><?php 
                                if(!empty($cmo['header_info_email']) ) {
                                    echo esc_html($cmo['header_info_email']); 
                                } 
                                ?> </p>
                            </div>
                        </div>
                    </div><!-- Contact Area Section End -->
        <?php
	}

	public function form($instance){
		$title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';

		?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title'));?>"><?php _e('Title:','cmo');?></label>
			<input id="<?php echo esc_attr($this->get_field_id('title'));?>" type="text"
			       name="<?php echo esc_attr($this->get_field_name('title'));?>" value="<?php echo esc_attr($title);?>" class="widefat title">
		</p>
		<?php
	}

	public function update($new_instance,$old_instance){
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];

		return $instance;
	}
}

class cmo_services extends WP_Widget{
	public function __construct(){
		parent::__construct('cmo_service',__('CMO Service','cmo'),array(
			'description' => __('this contact Widget only for single service page','cmo'),
		));
	}

	public function widget($args, $instance){

        $title = $instance['title'];
        ?>
                <!-- Srart service Area -->
                <div class="service-area">
                        <h2><?php echo wp_kses_post($args['before_widget'].$args['before_title'].$title.$args['after_title'].$args['after_widget']); ?></h2>
                        <ul>
                            <?php query_posts( array(
                                'post_type' => 'service',
                                'post_per_page' => -1,
                              )); 
                            ?>
                            <?php while (have_posts()) : the_post(); ?>
                            <li><a href="<?php the_permalink(); ?>"><i class="fa fa-angle-double-right"></i> <?php the_title(); ?></a></li>
                            <?php endwhile; ?>
                            <?php wp_reset_query(); ?>
                        </ul>
                    </div> <!-- End service Area -->
        <?php
	}

	public function form($instance){
        $title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';

		?>
		<p>
            <label for="<?php echo esc_attr($this->get_field_id('title'));?>"><?php _e('Title:','cmo');?></label>
			<input id="<?php echo esc_attr($this->get_field_id('title'));?>" type="text"
			       name="<?php echo esc_attr($this->get_field_name('title'));?>" value="<?php echo esc_attr($title);?>" class="widefat title">
		</p>
		<?php
	}

	public function update($new_instance,$old_instance){
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];

		return $instance;
	}
}

function cmo_custom_widgets(){
register_widget('cmo_contact');
register_widget('cmo_services');
}
add_action('widgets_init','cmo_custom_widgets');