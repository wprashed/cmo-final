<?php
class Elementor_CMOAbout_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return "about";
    }

	public function get_title() {
        return __('CMO: About','cmoelementorwidgets');
    }

	public function get_icon() {
        return 'fa fa-user';
    }

	public function get_categories() {
        return array('cmocategory');
    }

	protected function _register_controls() {


        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Background

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'cmoelementorwidgets' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .business-partner',
			]
		);

		// Margin

		$this->add_control(
			'margin',
			[
				'label' => __( 'Margin', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .business-partner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// Padding

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .business-partner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'abouttitle',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
        );
        
        $this->add_control(
			'aboutsubtitle',
			[
				'label' => __( 'subtitle', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'subtitle', 'cmoelementorwidgets' ),
			]
        );
        $this->add_control(
			'aboutcontent',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Type something', 'cmoelementorwidgets' ),
			]
        );

        $this->add_control(
			'aboutimage',
			[
				'label' => __( 'Image', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' =>[
                    'url' =>   \Elementor\Utils::get_placeholder_image_src(),
                ]
			]
        );
        $this->end_controls_section();

        //mission section
        $this->start_controls_section(
			'missiongoal_section',
			[
				'label' => __( 'Mission Goal', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'icon_one',
			[
				'label' => __( 'Icon', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'default' => 'fa fa-facebook',
			]
		);

		$this->add_control(
			'misgoltitle',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
        );
        $this->add_control(
			'misgolurl',
			[
				'label' => __( 'Url', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://exmaple.com', 'cmoelementorwidgets' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
        );
        $this->add_control(
			'misgolcontent',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Type something', 'cmoelementorwidgets' ),
			]
        );
        $this->add_control(
			'icon_two',
			[
				'label' => __( 'Icon', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'default' => 'fa fa-facebook',
			]
		);
        $this->add_control(
			'misgoltotitle',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
        );

        $this->add_control(
			'misgoltourl',
			[
				'label' => __( 'Url', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://exmaple.com', 'cmoelementorwidgets' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
        );
        
        $this->add_control(
			'misgoltocontent',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Type  something', 'cmoelementorwidgets' ),
			]
        );
        
        $this->end_controls_section();
        
        //for position
        $this->start_controls_section(
			'position_section',
			[
				'label' => __( 'Position', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'abouttitlealigment',
			[
				'label' => __( 'Title Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .about-text h6' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->add_control(
			'aboutsubtitlealigment',
			[
				'label' => __( 'Subtitle Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .about-text h3' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->add_control(
			'aboutcontentaligment',
			[
				'label' => __( 'Subtitle Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .about-text p' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->add_control(
			'aboutmisgolaligment',
			[
				'label' => __( 'Mission Area', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} div.mis-go-area' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->end_controls_section();

        //for color
		$this->start_controls_section(
			'color_section',
			[
				'label' => __( 'Color', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'aboutttitlecolor',
			[
				'label' => __( 'Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#bfc5cf',
                'selectors' => [
                    '{{WRAPPER}} .about-text h6' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->add_control(
			'aboutsubtitlecolor',
			[
				'label' => __( 'Subtitle Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} .about-text h3' => 'color: {{VALUE}}'
                ]
			]
		);
		$this->add_control(
			'aboutcontentcolor',
			[
				'label' => __( 'Content Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#8f9bb5',
                'selectors' => [
                    '{{WRAPPER}} .about-text p' => 'color: {{VALUE}}'
                ]
			]
		);

        $this->add_control(
			'aboutbuttoncolor',
			[
				'label' => __( 'Mission Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} .mis-go-area h6' => 'color: {{VALUE}}',
                ]
			]
        );

        $this->add_control(
			'iconcolor',
			[
				'label' => __( 'Mission Icon Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#228AE6',
                'selectors' => [
                    '{{WRAPPER}} .micon' => 'color: {{VALUE}}',
                ]
			]
        );

        $this->add_control(
			'iconhovercolor',
			[
				'label' => __( 'Mission Icon Hover Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#FF3E58',
                'selectors' => [
                    '{{WRAPPER}} .micon i:hover' => 'color: {{VALUE}}',
                ]
			]
        );

        $this->add_control(
			'aboutbuttonhocolor',
			[
				'label' => __( 'Mission Title Hover Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ff5e14',
                'selectors' => [
                    '{{WRAPPER}} .mis-go-area h6 a:hover' => 'color: {{VALUE}}',
                ]
			]
        );
        $this->add_control(
			'aboutbuttonbg',
			[
				'label' => __( 'Mission Content Collor', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#8f9bb5',
                'selectors' => [
                    '{{WRAPPER}} .mis-go-area p' => 'color: {{VALUE}}',
                ]
			]
		);
		
        $this->end_controls_section();

    }

	protected function render() {
        $settings = $this->get_settings_for_display();
        $abouttitle = $settings['abouttitle'];
        $aboutsubtitle = $settings['aboutsubtitle'];
        $aboutcontent = $settings['aboutcontent'];

        $aboutimage = $settings['aboutimage']['url'];

        //mission goal
        $misgolimage = $settings['misgolimage']['url'];
        $misgoltitle = $settings['misgoltitle'];
        $misgolurl = $settings['misgolurl']['url'];
        $misgolcontent = $settings['misgolcontent'];
        $misgoltoimage = $settings['misgoltoimage']['url'];
        $misgoltotitle = $settings['misgoltotitle'];
        $misgoltourl = $settings['misgoltourl']['url'];
        $misgoltocontent = $settings['misgoltocontent'];

        // for inline editing
        $this->add_inline_editing_attributes('abouttitle','none');
		$this->add_inline_editing_attributes('aboutsubtitle','none');
        $this->add_inline_editing_attributes('aboutcontent','none');
        
        $this->add_inline_editing_attributes('misgoltitle','none');
        $this->add_inline_editing_attributes('misgolcontent','none');
        $this->add_inline_editing_attributes('misgoltotitle','none');
        $this->add_inline_editing_attributes('misgoltocontent','none');
        
       ?>
<!--start-trusted-business-partner-->
<section class="business-partner">
    <div class="container">
        <!--start-who-we-are-->
        <div class="h2-who-we-are">
            <div class="row">
                <div class="col-lg-5 col-md-12 col-xm-12 align-self-center">
                    <div class="who-we-img">
                        <img src="<?php echo esc_url($aboutimage)?>" alt="bsn-img" class="img-responsive">
                    </div>
                </div>
                <div class="col-lg-7 col-sm-12 col-xm-12">
                    <div class="content-area">
                        <div class="about-text">
                            <h6 <?php echo $this->get_render_attribute_string('abouttitle');?>><?php echo esc_html($abouttitle);?></h6>
                            <h3 <?php echo $this->get_render_attribute_string('aboutsubtitle');?>><?php echo esc_html($aboutsubtitle);?></h3>
                            <p <?php echo $this->get_render_attribute_string('aboutcontent');?>><?php echo esc_html($aboutcontent);?></p>
                        </div>
                        <div class="mis-go-area">
                            <div class="mission">
                                <a href="<?php echo esc_url($misgolurl);?>" class="micon"><i class="<?php echo $settings['icon_one'] ?> fa-4x"></i></a>
                                <h6><a href="<?php echo esc_url($misgolurl);?>" <?php echo $this->get_render_attribute_string('misgoltitle');?>><?php echo esc_html($misgoltitle);?></a></h6>
                                <p <?php echo $this->get_render_attribute_string('misgolcontent');?>><?php echo esc_html($misgolcontent);?></p>
                            </div>
                            <div class="goal">
                                <a href="<?php echo esc_url($misgoltourl);?>" class="micon"><i class="<?php echo $settings['icon_two'] ?> fa-4x"></i></a>
                                <h6><a href="<?php echo esc_url($misgoltourl);?>" <?php echo $this->get_render_attribute_string('misgoltotitle');?>><?php echo esc_html($misgoltotitle);?></a></h6>
                                <p <?php echo $this->get_render_attribute_string('misgoltocontent');?>><?php echo esc_html($misgoltocontent);?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end-who-we-are-->
    </div><!--end-container-->
</section><!--end-trusted-business-partner-->
       <?php
    }

	protected function _content_template() {}

}