<?php

class Elementor_CMOTeam_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'Team';
	}

	public function get_title() {
		return __( 'CMO: Team', 'elementor' );
	}
	public function get_icon() {
        return 'fas fa-user-friends';
    }

	public function get_categories() {
        return array('cmocategory');
    }
	protected function _register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Background

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'cmoelementorwidgets' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .team-section',
			]
		);

		// Margin

		$this->add_control(
			'margin',
			[
				'label' => __( 'Margin', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .team-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Padding

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .team-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'teamttitle',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
		);
		$this->add_control(
			'teamsubtitle',
			[
				'label' => __( 'Subtitle', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Subtitle', 'cmoelementorwidgets' ),
			]
		);
		$this->end_controls_section();


		// for button
		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Button', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'teambtn',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
		);
		$this->add_control(
			'teambtnlink',
			[
				'label' => __( 'Url', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://example.com', 'cmoelementorwidgets' ),
			]
		);
		$this->end_controls_section();

		//for color
		$this->start_controls_section(
			'color_section',
			[
				'label' => __( 'Color', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'teamttitlecolor',
			[
				'label' => __( 'Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#737f9a',
                'selectors' => [
                    '{{WRAPPER}} .sec-title h4' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->add_control(
			'teamsubtitlecolor',
			[
				'label' => __( 'Subtitle Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} .sec-title h2' => 'color: {{VALUE}}'
                ]
			]
		);

        $this->add_control(
			'teambuttoncolor',
			[
				'label' => __( 'Button Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} a.btn' => 'color: {{VALUE}}',
                ]
			]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'teambuttonbg',
				'label' => __( 'Button Background', 'cmoelementorwidgets' ),
				'types' => [ 'gradient'],
                'selector' => '{{WRAPPER}} a.btn',
			]
		);
		$this->end_controls_section();
		// post control
        $this->start_controls_section(
			'team_post_control_section',
			[
				'label' => __( 'Post Control', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'teampostperpage',
			[
				'label' => __( 'Post Per Page', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
			]
        );
        $this->add_control(
			'teampostorderby',
			[
				'label' => __( 'Order By', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' =>'title',
				'options' => [
					'title'  => __( 'Title', 'cmoelementorwidgets' ),
					'date' => __( 'Date', 'cmoelementorwidgets' ),
                ],
			]
        );
        $this->add_control(
			'teampostorder',
			[
				'label' => __( 'Order', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' =>'ASC',
				'options' => [
					'ASC'  => __( 'ASC', 'cmoelementorwidgets' ),
					'DESC' => __( 'DESC', 'cmoelementorwidgets' ),
                ],
			]
        );
        $this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$teamttitle = $settings['teamttitle'];
		$teamsubtitle = $settings['teamsubtitle'];

		//for post control
		$teampostperpage = $settings['teampostperpage'];
        $teampostorderby = $settings['teampostorderby'];
        $teampostorder = $settings['teampostorder'];

		//for button
		$teambtn = $settings['teambtn'];
		$teambtnlink = $settings['teambtnlink']['url'];

		// for inline editing
		$this->add_inline_editing_attributes('teamttitle','none');
		$this->add_inline_editing_attributes('teamsubtitle','none');
		$this->add_inline_editing_attributes('teambtn','none');
		$this->add_render_attribute('teambtn',[
            'class' => "btn"
        ]);

        $the_query = new WP_Query( array(
            'post_type' => 'team',
            'posts_per_page' => $teampostperpage,
            'orderby' => $teampostorderby,
            'order' => $teampostorder
        ));
		?>
<!--Team-section-start-->
<section class="team-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-2">
                <!--start-team-title-->
                <div class="sec-title text-center">
                    <h4 <?php echo $this->get_render_attribute_string('teamttitle');?>><?php echo esc_html($teamttitle);?></h4>
                    <h2 <?php echo $this->get_render_attribute_string('teamsubtitle');?>><?php echo esc_html($teamsubtitle);?></h2>
                </div><!--end-team-title-->
            </div>
        </div><!--end-row-->
        <div class="row">
        <?php
        if($the_query->have_posts()):
         while($the_query->have_posts()): 
            $the_query->the_post();
            $designation  = get_post_meta( get_the_ID(), '_cmo_designation', true );
            $facebook  = get_post_meta( get_the_ID(), '_cmo_facebook', true );
            $linkedin  = get_post_meta( get_the_ID(), '_cmo_linkedin', true );
            $twitter  = get_post_meta( get_the_ID(), '_cmo_twitter', true );
            $profile  = get_post_meta( get_the_ID(), '_cmo_profile', true );
         ?>
            <div class="col-lg-4 col-md-6 col-sm-12 col-xm-12">
                <!--start-single-img-->
                <div class="single-img wow pulse">
                    <img src="<?php echo esc_url(get_post_meta(get_the_ID(),'_cmo_photo', true)); ?>" alt="Ariana Miller"/>
                    <!--profile-link-start-->
                    <div class="profile-link">
                        <a href="<?php echo esc_url($profile);?>"><i class="fa fa-link"></i></a>
                    </div><!--profile-link-end-->
                    <!--Teammate-social-link-start-->
                    <div class="social-link">
                        <ul>
                            <li><a href="<?php echo esc_url($twitter);?>"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="<?php echo esc_url($linkedin);?>"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="<?php echo esc_url($facebook);?>"><i class="fa fa-facebook-f"></i></a></li>
                        </ul>
                    </div><!--Teammate-social-link-end-->
                </div><!--end-single-img-->
                <!--start-single-image-title-->
                <div class="simg-title text-center">
                    <h3><?php the_title();?></h3>
                    <p><?php echo esc_html($designation);?></p>
                </div><!--end-single-image-title-->
            </div>
    <?php 
    endwhile;
    endif;
    wp_reset_query();
    ?>
        </div><!--end-row-->
        <div class="row">
            <div class="col-lg-12">
                <div class="team-area-btn text-center">
                    <a <?php echo $this->get_render_attribute_string('teambtn');?> href="<?php echo esc_url($teambtnlink);?>"><?php echo esc_html($teambtn);?></a>
                </div>
            </div>
        </div><!--end-row-->
    </div><!--end-container-->
</section><!--Team-section-end-->
		<?php
	}

	protected function _content_template() {
	
	}
}