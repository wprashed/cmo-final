<?php
class Elementor_CMOServicevtree_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return "Service v3";
    }

	public function get_title() {
        return __('CMO: Service v3','cmoelementorwidgets');
    }

	public function get_icon() {
        return 'fab fa-elementor';
    }

	public function get_categories() {
        return array('cmocategory');
    }

	protected function _register_controls() {
       
        // post control
        $this->start_controls_section(
			'servic_post_control_section',
			[
				'label' => __( 'Post Control', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        
        // Background

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => __( 'Background', 'cmoelementorwidgets' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .business-partner',
            ]
        );

        // Margin

        $this->add_control(
            'margin',
            [
                'label' => __( 'Margin', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .business-partner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Padding

        $this->add_control(
            'padding',
            [
                'label' => __( 'Padding', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .business-partner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
			'servicepostperpage',
			[
				'label' => __( 'Post Per Page', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5,
			]
        );
        $this->add_control(
			'servicepostorderby',
			[
				'label' => __( 'Order By', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' =>'title',
				'options' => [
					'title'  => __( 'Title', 'cmoelementorwidgets' ),
					'date' => __( 'Date', 'cmoelementorwidgets' ),
                ],
			]
        );
        $this->add_control(
			'servicepostorder',
			[
				'label' => __( 'Order', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' =>'ASC',
				'options' => [
					'ASC'  => __( 'ASC', 'cmoelementorwidgets' ),
					'DESC' => __( 'DESC', 'cmoelementorwidgets' ),
                ],
			]
        );
        $this->end_controls_section();
    }

	protected function render() {
        $settings = $this->get_settings_for_display();
        
        $servicepostperpage =  $settings['servicepostperpage'];
        $servicepostorderby =  $settings['servicepostorderby'];
        $servicepostorder =  $settings['servicepostorder'];


        $this->add_inline_editing_attributes('servicetitle','basic');
        $this->add_render_attribute('servicetitle',[
            'class' => "what-title"
        ]);
        $this->add_inline_editing_attributes('servicesubtitle','none');
        $this->add_render_attribute('servicesubtitle',[
            'class' => "what-subtitle"
        ]);

        $this->add_inline_editing_attributes('servicebutton','basic');
        $this->add_render_attribute('servicebutton',[
            'class' => "btn"
        ]);
        ?>
<!--start-business-gallery-->
<section class="business-partner">
    <div class="container">
        <div class="business-img-gallery">
            <div class="row">
            <?php $the_query = new WP_Query( array(
                        'post_type' => 'service',
                        'posts_per_page' => $servicepostperpage,
                        'orderby' => $servicepostorderby,
                        'order' => $servicepostorder
                    ));
                    while ($the_query->have_posts()) : $the_query->the_post();
                        $terms = get_the_terms ($the_query->ID, 'service_category');
                    ?>
                <div class="col-lg-4 col-md-4 col-sm-12 col-xm-12">
                    <!--start-business-sec-img-->
                    <div class="business-single-img">
                        <img src="<?php the_post_thumbnail_url('large');?>" alt="image"/>
                        <!--start-img-text-->
                        <div class="business-single-img-text"> 
                        <p><?php the_terms(get_the_id(), 'service_category', ' ' ); ?></p>                        
                            <a href="<?php the_permalink();?>"><h2><?php the_title(); ?></h2></a>
                        </div><!--end-img-text-->
                    </div><!--end-business-sec-img-->
                </div>
            <?php 
        endwhile; ?>
            <?php wp_reset_query(); ?>
            </div>
        </div><!--end-business-gallery-->
    </div>
</section>
        <?php
    }

	protected function _content_template() {}

}