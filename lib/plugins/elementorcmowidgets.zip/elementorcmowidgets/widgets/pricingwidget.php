<?php

class Elementor_CMOPricing_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'pricing';
	}

	public function get_title() {
		return __( 'CMO: Pricing', 'elementor' );
	}
	public function get_icon() {
        return 'far fa-money-bill-alt';
    }

	public function get_categories() {
        return array('cmocategory');
    }
	protected function _register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Background

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'cmoelementorwidgets' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .section-padding',
			]
		);

		// Margin

		$this->add_control(
			'margin',
			[
				'label' => __( 'Margin', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .section-padding' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Padding

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .section-padding' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'pricingttitle',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
		);
		$this->add_control(
			'pricingcontent',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Content', 'cmoelementorwidgets' ),
			]
        );
		$this->end_controls_section();

		//for monthly 
		$this->start_controls_section(
			'monthly_section',
			[
				'label' => __( 'Monthly Price', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'monthtab',
			[
				'label' => __( 'Tab Label', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Monthly', 'cmoelementorwidgets' ),
			]
		);
		//repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'mntpgname', [
				'label' => __( 'Package Name', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Package Name', 'cmoelementorwidgets' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'mnpgprice', [
				'label' => __( 'Price', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Add Price', 'cmoelementorwidgets' ),
			]
		);

		$repeater->add_control(
			'mnpglist1', [
				'label' => __( 'List 1', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Add List', 'cmoelementorwidgets' ),
			]
		);
		$repeater->add_control(
			'mnpglist2', [
				'label' => __( 'List 2', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Add List', 'cmoelementorwidgets' ),
			]
		);
		$repeater->add_control(
			'mnpglist3', [
				'label' => __( 'List 3', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Add List', 'cmoelementorwidgets' ),
			]
		);
		$repeater->add_control(
			'mnpglist4', [
				'label' => __( 'List 4', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Add List', 'cmoelementorwidgets' ),
			]
		);
		$repeater->add_control(
			'mnpglist5', [
				'label' => __( 'List 5', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Add List', 'cmoelementorwidgets' ),
			]
		);

		$repeater->add_control(
			'mnpgbutton', [
				'label' => __( 'Button Label', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'sing up', 'cmoelementorwidgets' ),
			]
		);
		$repeater->add_control(
			'mnpgbuttonurl', [
				'label' => __( 'Button Url', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'example.com', 'cmoelementorwidgets' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->add_control(
			'mnpgdetails',
			[
				'label' => __( 'Details', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'mntpgname' => __( ' ', 'cmoelementorwidgets' ),
						'mnpgprice' => __( ' ', 'cmoelementorwidgets' ),
						'mnpglist1' => __( ' ', 'cmoelementorwidgets' ),
						'mnpglist2' => __( ' ', 'cmoelementorwidgets' ),
						'mnpglist3' => __( ' ', 'cmoelementorwidgets' ),
						'mnpglist4' => __( ' ', 'cmoelementorwidgets' ),
						'mnpglist5' => __( ' ', 'cmoelementorwidgets' ),
						'mnpgbutton' => __( ' ', 'cmoelementorwidgets' ),
						'mnpgbuttonurl' => __( ' ', 'cmoelementorwidgets' ),
					],
					
				],
				'title_field' => '{{{ mntpgname }}}',
			]
		);

		$this->end_controls_section();


		//for Annual 
		$this->start_controls_section(
			'annual_section',
			[
				'label' => __( 'Annual Price', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'annualtab',
			[
				'label' => __( 'Tab Label', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Annual', 'cmoelementorwidgets' ),
			]
		);
		//repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'anlpgname', [
				'label' => __( 'Package Name', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Package Name', 'cmoelementorwidgets' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'anlpgprice', [
				'label' => __( 'Price', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Add Price', 'cmoelementorwidgets' ),
			]
		);

		$repeater->add_control(
			'anlpglist1', [
				'label' => __( 'List 1', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Add List', 'cmoelementorwidgets' ),
			]
		);
		$repeater->add_control(
			'anlpglist2', [
				'label' => __( 'List 2', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Add List', 'cmoelementorwidgets' ),
			]
		);
		$repeater->add_control(
			'anlpglist3', [
				'label' => __( 'List 3', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Add List', 'cmoelementorwidgets' ),
			]
		);
		$repeater->add_control(
			'anlpglist4', [
				'label' => __( 'List 4', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Add List', 'cmoelementorwidgets' ),
			]
		);
		$repeater->add_control(
			'anlpglist5', [
				'label' => __( 'List 5', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Add List', 'cmoelementorwidgets' ),
			]
		);

		$repeater->add_control(
			'anlpgbutton', [
				'label' => __( 'Button Label', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'sing up', 'cmoelementorwidgets' ),
			]
		);
		$repeater->add_control(
			'anlpgbuttonurl', [
				'label' => __( 'Button Url', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'example.com', 'cmoelementorwidgets' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->add_control(
			'anlpgdetails',
			[
				'label' => __( 'Details', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'anlpgname' => __( ' ', 'cmoelementorwidgets' ),
						'anlpgprice' => __( ' ', 'cmoelementorwidgets' ),
						'anlpglist1' => __( ' ', 'cmoelementorwidgets' ),
						'anlpglist2' => __( ' ', 'cmoelementorwidgets' ),
						'anlpglist3' => __( ' ', 'cmoelementorwidgets' ),
						'anlpglist4' => __( ' ', 'cmoelementorwidgets' ),
						'anlpglist5' => __( ' ', 'cmoelementorwidgets' ),
						'anlpgbutton' => __( ' ', 'cmoelementorwidgets' ),
						'anlpgbuttonurl' => __( ' ', 'cmoelementorwidgets' ),
					],
					
				],
				'title_field' => '{{{ anlpgname }}}',
			]
		);

		$this->end_controls_section();

		//for color
		$this->start_controls_section(
			'color_section',
			[
				'label' => __( 'Color', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'pricingttitlecolor',
			[
				'label' => __( 'Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} h2.title' => 'color: {{VALUE}}'
                ]
			]
        );
		$this->add_control(
			'pricingcontentcolor',
			[
				'label' => __( 'Content Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#8f9bb5',
                'selectors' => [
                    '{{WRAPPER}} p.descriotion' => 'color: {{VALUE}}'
                ]
			]
		);
        $this->add_control(
			'pricingbuttoncolor',
			[
				'label' => __( 'Button Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ff5e14',
                'selectors' => [
                    '{{WRAPPER}} .nav-tabs a' => 'color: {{VALUE}}',
                ]
			]
        );
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'pricingbuttonbg',
				'label' => __( 'Button Background', 'cmoelementorwidgets' ),
				'types' => [ 'gradient'],
                'selector' => '{{WRAPPER}} .nav-tabs a',
			]
		);
		$this->add_control(
			'pricingatbuttoncolor',
			[
				'label' => __( 'Active Button Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .nav-tabs a.active' => 'color: {{VALUE}}',
                ]
			]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'pricingatbuttonbg',
				'label' => __( 'Active Button Backgound', 'cmoelementorwidgets' ),
				'types' => [ 'gradient'],
                'selector' => '{{WRAPPER}} .nav-tabs .nav-link.active',
			]
		);
		//item
		$this->add_control(
			'pricingititlecolor',
			[
				'label' => __( 'Item Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-plan h4' => 'color: {{VALUE}}'
                ]
			]
        );
		$this->add_control(
			'pricingicontentcolor',
			[
				'label' => __( 'Item Content Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#8f9bb5',
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-plan li' => 'color: {{VALUE}}'
                ]
			]
		);
		$this->add_control(
			'pricingiptitlecolor',
			[
				'label' => __( 'Price Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-plan h2' => 'color: {{VALUE}}'
                ]
			]
        );
		$this->add_control(
			'pricingipcontentcolor',
			[
				'label' => __( 'Price Background', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ff5e14',
                'selectors' => [
                    '{{WRAPPER}} .single-pricing-plan h2' => 'background: {{VALUE}}'
                ]
			]
		);
        $this->add_control(
			'ipricingbuttoncolor',
			[
				'label' => __( 'Button Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ff5e14',
                'selectors' => [
                    '{{WRAPPER}} a.sing-btn' => 'color: {{VALUE}}',
                ]
			]
        );
        $this->add_control(
			'ipricingbuttonbg',
			[
				'label' => __( 'Button Backgound', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} a.sing-btn' => 'background: {{VALUE}}',
                ]
			]
		);
		$this->add_control(
			'ipricingatbuttoncolor',
			[
				'label' => __( 'Button Hover Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .card.card-pricing:hover a.sing-btn' => 'color: {{VALUE}}',
                ]
			]
        );
		$this->add_control(
			'ipricingatbuttonbg',
			[
				'label' => __( 'Button Hover Backgound', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ff5e14',
                'selectors' => [
                    '{{WRAPPER}} .card.card-pricing:hover a.sing-btn' => 'background: {{VALUE}}',
                ]
			]
		);
		
        $this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$pricingttitle = $settings['pricingttitle'];
		$pricingcontent = $settings['pricingcontent'];


		// for repeater value for monthly
		$monthtab = $settings['monthtab'];
		$list =$settings['mnpgdetails'];

		// for repeater value for annual
		$annualtab = $settings['annualtab'];
		$anllist =$settings['anlpgdetails'];

		// for inline editing
		$this->add_inline_editing_attributes('pricingttitle','none');
		$this->add_inline_editing_attributes('pricingcontent','none');
		$this->add_inline_editing_attributes('pricingbtn','none');
		$this->add_render_attribute('pricingttitle',[
            'class' => "title"
        ]);
		$this->add_render_attribute('pricingcontent',[
            'class' => "descriotion"
        ]);
		?>
        <section class="section-padding">
            <div class="container">
                <div class="pricing-table">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h2 <?php echo $this->get_render_attribute_string('pricingttitle');?>><?php echo esc_html($pricingttitle);?></h2>
                            <p <?php echo $this->get_render_attribute_string('pricingcontent');?>>
							<?php echo wp_kses_post($pricingcontent);?>
                            </p>
                            <div class="section-space"></div>
                        </div>
                    </div>
                    <div class="row">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
						<?php if(!empty($monthtab)){?>
                          <li class="nav-item">
                             <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true"><?php echo esc_html($monthtab);?></a>
                          </li>
						  <?php
						}
						  if(!empty($annualtab)){?>
                          <li class="nav-item">
                             <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false"><?php echo esc_html($annualtab);?></a>
                          </li>
						  <?php } ?>
                        </ul>
                    </div>
                    <div class="tab-content pt-5" id="myTabContent">
                      <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <div class="row">
						<?php 
							if ( $list ) {
							foreach (  $list as $item ) {
								$target = $item['mnpgbuttonurl']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $item['mnpgbuttonurl']['nofollow'] ? ' rel="nofollow"' : '';
						?>
						<div class="col-md-4 elementor-repeater-item-<?php echo esc_html($item['_id']);?>">
                            <div class="card card-pricing">
                                <div class="card-body ">
                                    <div class="single-pricing-plan text-center">
                                       <h4 class="pt-4"><?php echo esc_html($item['mntpgname']);?></h4>
                                       <h2><small><?php _e('$ ','cmoelementorwidgets');?></small><?php echo esc_html($item['mnpgprice']);?></h2>
                                       <ul>
                                           <li><?php echo esc_html($item['mnpglist1']);?></li>
                                           <hr>
                                           <li><?php echo esc_html($item['mnpglist2']);?></li>
                                           <hr>
                                           <li><?php echo esc_html($item['mnpglist3']);?></li>
                                           <hr>
                                           <li><?php echo esc_html($item['mnpglist4']);?></li>
                                           <hr>
                                           <li><?php echo esc_html($item['mnpglist5']);?></li>
                                       </ul>
                                        <div class="card-footer">
                                            <a href="<?php echo esc_url($item['mnpgbuttonurl']['url']);?>" class="sing-btn" <?php echo $target; echo $nofollow; ?>><?php echo esc_html($item['mnpgbutton']);?></a>
                                        </div>
                                   </div>
                                </div>
                            </div>
                        </div>
						<?php 
							}
							}
						?>
                        </div>
                      </div>
                      <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="row">
							<?php 
								if ( $anllist ) {
								foreach (  $anllist as $anlitem ) {
									$anltarget = $anlitem['anlpgbuttonurl']['is_external'] ? ' target="_blank"' : '';
									$anlnofollow = $anlitem['anlpgbuttonurl']['nofollow'] ? ' rel="nofollow"' : '';
									[
										'anlpgname' => __( ' ', 'cmoelementorwidgets' ),
										'anlpgprice' => __( ' ', 'cmoelementorwidgets' ),
										'anlpglist1' => __( ' ', 'cmoelementorwidgets' ),
										'anlpglist2' => __( ' ', 'cmoelementorwidgets' ),
										'anlpglist3' => __( ' ', 'cmoelementorwidgets' ),
										'anlpglist4' => __( ' ', 'cmoelementorwidgets' ),
										'anlpglist5' => __( ' ', 'cmoelementorwidgets' ),
										'anlpgbutton' => __( ' ', 'cmoelementorwidgets' ),
										'anlpgbuttonurl' => __( ' ', 'cmoelementorwidgets' ),
									]
							?>
                                <div class="col-md-4">
                                <div class="card card-pricing">
                                    <div class="card-body ">
                                        <div class="single-pricing-plan text-center">
                                           <h4 class="pt-4"><?php echo esc_html($anlitem['anlpgname']);?></h4>
                                           <h2><small><?php _e('$ ','cmoelementorwidgets');?></small><?php echo esc_html($anlitem['anlpgprice']);?></h2>
                                           <ul>
                                               <li><?php echo esc_html($anlitem['anlpglist1']);?></li>
                                               <hr>
                                               <li><?php echo esc_html($anlitem['anlpglist2']);?></li>
                                               <hr>
                                               <li><?php echo esc_html($anlitem['anlpglist3']);?></li>
                                               <hr>
                                               <li><?php echo esc_html($anlitem['anlpglist4']);?></li>
                                               <hr>
                                               <li><?php echo esc_html($anlitem['anlpglist5']);?></li>
                                           </ul>
                                            <div class="card-footer">
											<a href="<?php echo esc_url($anlitem['anlpgbuttonurl']['url']);?>" class="sing-btn" <?php echo $anltarget; echo $anlnofollow; ?>><?php echo esc_html($anlitem['anlpgbutton']);?></a>
                                            </div>
                                       </div>
                                    </div>
                                </div>
                            </div>
							<?php 
								}
								}
							?>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
        </section>

		<?php
	}

	protected function _content_template() {
	
	}
}