<?php
class Elementor_CMOWECAN_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return "We Can";
    }

	public function get_title() {
        return __('CMO: We Can','cmoelementorwidgets');
    }

	public function get_icon() {
        return 'fa fa-bolt';
    }

	public function get_categories() {
        return array('cmocategory');
    }

	protected function _register_controls() {
        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        // Background

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => __( 'Background', 'cmoelementorwidgets' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} #we-can',
            ]
        );

        // Margin

        $this->add_control(
            'margin',
            [
                'label' => __( 'Margin', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} #we-can' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Padding

        $this->add_control(
            'padding',
            [
                'label' => __( 'Padding', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} #we-can' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'enter section title', 'cmoelementorwidgets' ),
			]
        );

        $this->add_control(
			'content',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
				 'placeholder' => __( 'something..', 'cmoelementorwidgets' ),
			]
        );
        $this->end_controls_section();

//for Video
        $this->start_controls_section(
			'video_section',
			[
				'label' => __( 'Video', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
            'videoicon',
            [
                'label' => __( 'Video Icon', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::ICON,
                'default' => 'fa fa-youtube-play',
            ]
        );
        $this->add_control(
			'videolink',
			[
				'label' => __( 'Video Link', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'placeholder' => __( 'https://yourtube.com/andit', 'cmoelementorwidgets' ),
			]
        );
        $this->end_controls_section();

        $this->start_controls_section(
			'countdown_section',
			[
				'label' => __( 'Countdown', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        //1st
        $this->add_control(
            'icon_one',
            [
                'label' => __( '1st Icon', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::ICON,
                'default' => 'fa fa-globe',
            ]
        );
        $this->add_control(
			'countdownftitle',
			[
				'label' => __( '1st title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
        );
        $this->add_control(
            'countdownfnum',
            [
                'label' =>__('Count Number', 'cmoelementorwidgets'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' =>10,

            ]
        );

        //2nd
        $this->add_control(
            'icon_two',
            [
                'label' => __( '2nd Icon', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::ICON,
                'default' => 'fa fa-users',
            ]
        );
        $this->add_control(
			'countdownstitle',
			[
				'label' => __( '2nd title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
            ]
        );
        $this->add_control(
            'countdownsnum',
            [
                'label' =>__('Count Number', 'cmoelementorwidgets'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' =>10,

            ]
        );

        // 3rd
        $this->add_control(
            'icon_three',
            [
                'label' => __( '3rd Icon', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::ICON,
                'default' => 'fa fa-lightbulb-o',
            ]
        );
        $this->add_control(
			'countdowntrtitle',
			[
				'label' => __( '3rd title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
        );
        $this->add_control(
            'countdowntrnum',
            [
                'label' =>__('Count Number', 'cmoelementorwidgets'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' =>10,

            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'color_section',
			[
				'label' => __( 'Color', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'titlecolor',
			[
				'label' => __( 'Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#e3dec2',
                'selectors' => [
                    '{{WRAPPER}} .we-can-text h2' => 'color: {{VALUE}}'
                ]
			]
        );

        $this->add_control(
            'videoiconcolor',
            [
                'label' => __( 'Title Color', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#228AE6',
                'selectors' => [
                    '{{WRAPPER}} .popup-youtube i' => 'color: {{VALUE}}'
                ]
            ]
        );

        $this->add_control(
            'countericoncolor',
            [
                'label' => __( 'Title Color', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#228AE6',
                'selectors' => [
                    '{{WRAPPER}} .count-img i' => 'color: {{VALUE}}'
                ]
            ]
        );

        $this->add_control(
			'contentcolor',
			[
				'label' => __( 'Content Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#8f9bb5',
                'selectors' => [
                    '{{WRAPPER}} .we-can-text p' => 'color: {{VALUE}}'
                ]
			]
        );

        //count color
        $this->add_control(
			'countercolor',
			[
				'label' => __( 'Counter Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#e3dec2',
                'selectors' => [
                    '{{WRAPPER}} span.counter' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->add_control(
			'countertitlecolor',
			[
				'label' => __( 'Counter Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#8f9bb5',
                'selectors' => [
                    '{{WRAPPER}} .count-it-text p' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->end_controls_section();
    }

	protected function render() {
        $settings           = $this->get_settings_for_display();
        $title              = $settings['title'];
        $content            = $settings['content'];
        $videolink          =  $settings['videolink'];

        $countdownficon     = $settings['countdownficon']['url'];
        $countdownftitle    =$settings['countdownftitle'];
        $countdownfnum      = $settings['countdownfnum'];
        $countdownsicon     = $settings['countdownsicon']['url'];
        $countdownstitle    =$settings['countdownstitle'];
        $countdownsnum      = $settings['countdownsnum'];
        $countdowntricon     = $settings['countdowntricon']['url'];
        $countdowntrtitle    =$settings['countdowntrtitle'];
        $countdowntrnum      = $settings['countdowntrnum'];


        $this->add_inline_editing_attributes('title','none');
        $this->add_inline_editing_attributes('content','none');

        $this->add_inline_editing_attributes('countdownfnum','none');
        $this->add_render_attribute('countdownfnum',[
            'class' => "counter"
        ]);
        $this->add_inline_editing_attributes('countdownsnum','none');
        $this->add_render_attribute('countdownsnum',[
            'class' => "counter"
        ]);
        $this->add_inline_editing_attributes('countdowntrnum','none');
        $this->add_render_attribute('countdowntrnum',[
            'class' => "counter"
        ]);

        $this->add_inline_editing_attributes('countdownftitle','none');
        $this->add_inline_editing_attributes('countdownstitle','none');
        $this->add_inline_editing_attributes('countdowntrtitle','none');
        ?>
<!--We can Area Start-->
<section id="we-can">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12 align-self-center">
                <a class="popup-youtube video-con" href="<?php echo esc_url($videolink);?>">
                    <i class="<?php echo $settings['videoicon'] ?> fa fa-play fa-2x"></i>
                </a>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12">
                <div class="we-can-total-text">
                    <div class="we-can-text">
                        <h2 <?php echo $this->get_render_attribute_string('title');?>><?php echo esc_html($title); ?></h2>
                        <p <?php echo $this->get_render_attribute_string('content');?>><?php echo esc_html($content); ?></p>
                    </div>
                    <div class="we-can-counter d-flex justify-content-between">
                        <div class="count-item d-flex">
                            <div class="count-img">
                                <i class="<?php echo $settings['icon_one'] ?> fa-5x"></i>
                            </div>
                            <div class="count-it-text">
                                <span <?php echo $this->get_render_attribute_string('countdownfnum')?>><?php echo esc_html($countdownfnum);?></span>
                                <p <?php echo $this->get_render_attribute_string('countdownftitle')?>><?php echo esc_html($countdownftitle);?></p>
                            </div>
                        </div>
                        <div class="count-item d-flex">
                            <div class="count-img">
                            <i class="<?php echo $settings['icon_two'] ?> fa-5x"></i>
                            </div>
                            <div class="count-it-text">
                            <span <?php echo $this->get_render_attribute_string('countdownsnum')?>><?php echo esc_html($countdownsnum);?></span>
                                <p <?php echo $this->get_render_attribute_string('countdownstitle')?>><?php echo esc_html($countdownstitle);?></p>
                            </div>
                        </div>
                        <div class="count-item d-flex">
                            <div class="count-img">
                            <i class="<?php echo $settings['icon_three'] ?> fa-5x"></i>
                            </div>
                            <div class="count-it-text">
                            <span <?php echo $this->get_render_attribute_string('countdowntrnum')?>><?php echo esc_html($countdowntrnum);?></span>
                                <p <?php echo $this->get_render_attribute_string('countdowntrtitle')?>><?php echo esc_html($countdowntrtitle);?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--We can Area End-->
        <?php
    }

	protected function _content_template() {}

}