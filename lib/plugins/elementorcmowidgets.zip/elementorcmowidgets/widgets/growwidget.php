<?php
class Elementor_CMOGrow_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return "grow";
    }

	public function get_title() {
        return __('CMO: Grow','cmoelementorwidgets');
    }

	public function get_icon() {
        return 'fa fa-expand';
    }

	public function get_categories() {
        return array('cmocategory');
    }

	protected function _register_controls() {
        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        // Background

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'cmoelementorwidgets' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} #lets-grow',
			]
		);

		// Margin

		$this->add_control(
			'margin',
			[
				'label' => __( 'Margin', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} #lets-grow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Padding

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} #lets-grow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'growtitle',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Type service title', 'cmoelementorwidgets' ),
			]
        );
        
        $this->add_control(
			'growsubtitle',
			[
				'label' => __( 'subtitle', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Type service subtitle', 'cmoelementorwidgets' ),
			]
        );
        $this->add_control(
			'growcontent',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Type service Content', 'cmoelementorwidgets' ),
			]
        );

        $this->add_control(
			'growbutton',
			[
				'label' => __( 'Button Label', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'careers',
			]
        );
        $this->add_control(
			'growbuttonurl',
			[
				'label' => __( 'Button Link', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://exmaple.com', 'cmoelementorwidgets' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
        );

        $this->add_control(
			'growimage',
			[
				'label' => __( 'Image', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' =>[
                    'url' =>   \Elementor\Utils::get_placeholder_image_src(),
                ]
			]
        );
        $this->end_controls_section();
        
        //for position
        $this->start_controls_section(
			'position_section',
			[
				'label' => __( 'Position', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'growtitlealigment',
			[
				'label' => __( 'Title Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .lets-grow-text h6' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->add_control(
			'growsubtitlealigment',
			[
				'label' => __( 'Subtitle Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .lets-grow-text h3' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->add_control(
			'growcontentaligment',
			[
				'label' => __( 'Subtitle Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .lets-grow-text p' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->add_control(
			'growbuttonaligment',
			[
				'label' => __( 'Button Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} div.banner-area-btn' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->end_controls_section();

        //for color
		$this->start_controls_section(
			'color_section',
			[
				'label' => __( 'Color', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'growttitlecolor',
			[
				'label' => __( 'Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#737f9a',
                'selectors' => [
                    '{{WRAPPER}} .lets-grow-text h6' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->add_control(
			'growsubtitlecolor',
			[
				'label' => __( 'Subtitle Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} .lets-grow-text h3' => 'color: {{VALUE}}'
                ]
			]
		);
		$this->add_control(
			'growcontentcolor',
			[
				'label' => __( 'Content Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#737f9a',
                'selectors' => [
                    '{{WRAPPER}} .lets-grow-text p' => 'color: {{VALUE}}'
                ]
			]
		);

        $this->add_control(
			'growbuttoncolor',
			[
				'label' => __( 'Button Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} a.btn' => 'color: {{VALUE}}',
                ]
			]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'growbuttonbg',
				'label' => __( 'Button Background', 'cmoelementorwidgets' ),
				'types' => [ 'gradient'],
                'selector' => '{{WRAPPER}} a.btn',
			]
		);
		
        $this->end_controls_section();

    }

	protected function render() {
        $settings = $this->get_settings_for_display();
        $growtitle = $settings['growtitle'];
        $growsubtitle = $settings['growsubtitle'];
        $growcontent = $settings['growcontent'];

        $growbutton = $settings['growbutton'];
        $growbuttonurl = $settings['growbuttonurl']['url'];
        $growimage = $settings['growimage']['url'];

        // for inline editing
        $this->add_inline_editing_attributes('growtitle','none');
		$this->add_inline_editing_attributes('growsubtitle','none');
		$this->add_inline_editing_attributes('growcontent','none');
        $this->add_inline_editing_attributes('growbutton','none');
        $this->add_render_attribute('growbutton',[
            'class' => "btn"
        ]);
        
       ?>
       <!--Lets Grow Area Start-->
<section id="lets-grow">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="lets-grow-text text-left">
                    <h6 <?php echo $this->get_render_attribute_string('growtitle');?>><?php echo esc_html($growtitle);?></h6>
                    <h3 <?php echo $this->get_render_attribute_string('growsubtitle');?>><?php echo wp_kses_post($growsubtitle);?></h3>
                    <p <?php echo $this->get_render_attribute_string('growcontent');?>><?php echo wp_kses_post($growcontent);?></p>
                    <div class="banner-area-btn">
                        <a <?php echo $this->get_render_attribute_string('growbutton');?> href="<?php echo esc_url($growbuttonurl);?>"><?php echo esc_html($growbutton);?></a>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="le-gr-img">
                    <a href=""><img src="<?php echo esc_url($growimage); ?>" alt="bsn-img" class="img-responsive"></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Lets Grow Area End-->
       <?php
    }

	protected function _content_template() {}

}