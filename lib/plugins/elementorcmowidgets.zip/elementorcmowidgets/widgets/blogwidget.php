<?php

class Elementor_CMOBlog_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'blog';
	}

	public function get_title() {
		return __( 'CMO: Blog', 'elementor' );
	}
	public function get_icon() {
        return 'fas fa-blog';
    }

	public function get_categories() {
        return array('cmocategory');
    }
	protected function _register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Background

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'cmoelementorwidgets' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} #blog',
			]
		);

		// Margin

		$this->add_control(
			'margin',
			[
				'label' => __( 'Margin', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} #blog' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Padding

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} #blog' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'blogttitle',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
		);
		$this->add_control(
			'blogsubtitle',
			[
				'label' => __( 'Subtitle', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Subtitle', 'cmoelementorwidgets' ),
			]
		);
		$this->end_controls_section();


		// for button
		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Button', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'blogbtn',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
		);
		$this->add_control(
			'blogbtnlink',
			[
				'label' => __( 'Url', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://example.com', 'cmoelementorwidgets' ),
			]
		);
		$this->end_controls_section();

		//for color
		$this->start_controls_section(
			'color_section',
			[
				'label' => __( 'Color', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'blogttitlecolor',
			[
				'label' => __( 'Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#737f9a',
                'selectors' => [
                    '{{WRAPPER}} .blog-head h6' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->add_control(
			'blogsubtitlecolor',
			[
				'label' => __( 'Subtitle Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} .blog-head h3' => 'color: {{VALUE}}'
                ]
			]
		);

        $this->add_control(
			'blogbuttoncolor',
			[
				'label' => __( 'Button Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} a.btn' => 'color: {{VALUE}}',
                ]
			]
        );
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'blogbuttonbg',
				'label' => __( 'Button Background', 'cmoelementorwidgets' ),
				'types' => [ 'gradient'],
                'selector' => '{{WRAPPER}} a.btn',
			]
		);
		
		$this->end_controls_section();
		// post control
        $this->start_controls_section(
			'blog_post_control_section',
			[
				'label' => __( 'Post Control', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'blogpostperpage',
			[
				'label' => __( 'Post Per Page', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
			]
        );
        $this->add_control(
			'blogpostorderby',
			[
				'label' => __( 'Order By', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' =>'title',
				'options' => [
					'title'  => __( 'Title', 'cmoelementorwidgets' ),
					'date' => __( 'Date', 'cmoelementorwidgets' ),
                ],
			]
        );
        $this->add_control(
			'blogpostorder',
			[
				'label' => __( 'Order', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' =>'ASC',
				'options' => [
					'ASC'  => __( 'ASC', 'cmoelementorwidgets' ),
					'DESC' => __( 'DESC', 'cmoelementorwidgets' ),
                ],
			]
        );
        $this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$blogttitle = $settings['blogttitle'];
		$blogsubtitle = $settings['blogsubtitle'];

		//for post control
		$blogpostperpage = $settings['blogpostperpage'];
        $blogpostorderby = $settings['blogpostorderby'];
        $blogpostorder = $settings['blogpostorder'];

		//for button
		$blogbtn = $settings['blogbtn'];
		$blogbtnlink = $settings['blogbtnlink']['url'];

		// for inline editing
		$this->add_inline_editing_attributes('blogttitle','none');
		$this->add_inline_editing_attributes('blogsubtitle','none');
		$this->add_inline_editing_attributes('blogbtn','none');
		$this->add_render_attribute('blogbtn',[
            'class' => "btn"
        ]);

        $the_query = new WP_Query( array(
            'post_type' => 'post',
            'posts_per_page' => $blogpostperpage,
            'orderby' => $blogpostorderby,
            'order' => $blogpostorder
        ));
		?>
<!--Blog Area Start-->
<section id="blog">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto text-center">
                <div class="blog-head">
					<h6 <?php echo $this->get_render_attribute_string('blogttitle');?>><?php echo esc_html($blogttitle);?></h6>
                    <h3 <?php echo $this->get_render_attribute_string('blogsubtitle');?>><?php echo esc_html($blogsubtitle);?></h3>
                </div>
            </div>
        </div>
        <div class="row">
		<?php
        if($the_query->have_posts()):
         while($the_query->have_posts()): 
			$the_query->the_post();
			?>
            <div class="col-md-4 col-sm-12 col-xm-12">
                <div class="blog-area-item">
                    <div class="blog-img">
						<a href="<?php the_permalink();?>" target="_blank"><img src="<?php the_post_thumbnail_url() ?>" alt="bsn-img"></a>
                    </div>
                    <div class="blog-text">
                    	<h5><a href="<?php the_permalink();?>" target="_blank"><?php the_title(); ?></a></h5>
                        <?php the_excerpt(); ?>
                    	<div class="d-flex justify-content-between">
                            <span><?php echo wp_kses_post(get_the_category_list()); ?></span> 
                            <span><?php the_author(); ?></span>
                        </div>
                    </div>
                </div>
			</div>
			<?php 
    endwhile;
    endif;
    wp_reset_query();
    ?>
        </div>
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="banner-area-btn home-blog">
				<a <?php echo $this->get_render_attribute_string('blogbtn');?> href="<?php echo esc_url($blogbtnlink);?>"><?php echo esc_html($blogbtn);?></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Blog Area End-->

		<?php
	}

	protected function _content_template() {
	
	}
}