<?php
class Elementor_CMOClient_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return "Client Slider";
    }

	public function get_title() {
        return __('CMO: Partner Silder','cmoelementorwidgets');
    }

	public function get_icon() {
        return 'fas fa-handshake';
    }

	public function get_categories() {
        return array('cmocategory');
    }

	protected function _register_controls() {
        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Client Slider', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        // Background

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => __( 'Background', 'cmoelementorwidgets' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} #partner',
            ]
        );

        // Margin

        $this->add_control(
            'margin',
            [
                'label' => __( 'Margin', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} #partner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Padding

        $this->add_control(
            'padding',
            [
                'label' => __( 'Padding', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} #partner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
			'clientpostperpage',
			[
				'label' => __( 'Post Per Page', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 9,
			]
        );
        $this->end_controls_section();
    }

	protected function render() {
        $settings           = $this->get_settings_for_display();
        $clientpostperpage =  $settings['clientpostperpage'];
        ?>
<!--Partner Area Start-->
<section id="partner">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 mx-auto">
                <div class="banner-slider partner-slider owl-carousel owl-theme">
                    <div class="item">
                        <div class="partner-img d-flex justify-content-between">
                        <?php 
                        $query = new WP_Query(array(
                            'post_type'         =>'client',
                            'posts_per_page'     => $clientpostperpage,
                        ));
                        if($query->have_posts()):
                            while($query->have_posts()):
                                $query->the_post();
                        ?>
                            <div class="part-item">
                                <a href="<?php echo esc_url(get_post_meta(get_the_ID(),'logo_link', true)); ?>"><img src="<?php echo esc_url(get_post_meta(get_the_ID(),'_cmo_client_logo', true)); ?>" alt="bsn-img"></a>
                            </div>
                        <?php
                        endwhile;
                        endif;
                        ?>
                        </div>
                    </div>
                    <div class="item">
                        <div class="partner-img d-flex justify-content-between">
                        <?php 
                        $query = new WP_Query(array(
                            'post_type'         =>'client',
                            'posts_per_page'     => $clientpostperpage,
                        ));
                        if($query->have_posts()):
                            while($query->have_posts()):
                                $query->the_post();
                        ?>
                            <div class="part-item">
                                <a href="<?php echo esc_url(get_post_meta(get_the_ID(),'logo_link', true)); ?>"><img src="<?php echo esc_url(get_post_meta(get_the_ID(),'_cmo_client_logo', true)); ?>" alt="bsn-img"></a>
                            </div>
                        <?php
                        endwhile;
                        endif;
                        ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Partner Area End-->

        <?php

    }

	protected function _content_template() {}

}