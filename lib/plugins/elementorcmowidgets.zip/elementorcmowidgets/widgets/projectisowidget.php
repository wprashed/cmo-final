<?php
class Elementor_ProjectIso_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return "portfolio2";
    }

	public function get_title() {
        return __('CMO: Portfolio 2','cmoelementorwidgets');
    }

	public function get_icon() {
        return 'fas fa-project-diagram';
    }

	public function get_categories() {
        return array('cmocategory');
    }

	protected function _register_controls() {
        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        // Background

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => __( 'Background', 'cmoelementorwidgets' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .projectewidget',
            ]
        );

        // Margin

        $this->add_control(
            'margin',
            [
                'label' => __( 'Margin', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .projectewidget' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Padding

        $this->add_control(
            'padding',
            [
                'label' => __( 'Padding', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .projectewidget' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
			'porttitle',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
        );
        
        $this->add_control(
			'portsubtitle',
			[
				'label' => __( 'subtitle', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Subtitle', 'cmoelementorwidgets' ),
			]
        );
        $this->add_control(
			'portcontent',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'content', 'cmoelementorwidgets' ),
			]
        );
        $this->end_controls_section();

        $this->start_controls_section(
			'color_section',
			[
				'label' => __( 'Color', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'porttitlecolor',
			[
				'label' => __( 'Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#939cb0',
                'selectors' => [
                    '{{WRAPPER}} .home-portfolio h5' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->add_control(
			'portsubtitlecolor',
			[
				'label' => __( 'Subtitle Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} .home-portfolio h2' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->add_control(
			'portbuttoncolor',
			[
				'label' => __( 'Content Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#8f9bb5',
                'selectors' => [
                    '{{WRAPPER}} .home-portfolio p' => 'color: {{VALUE}}',
                ]
			]
        );
        $this->end_controls_section();

        // post control
        $this->start_controls_section(
			'servic_post_control_section',
			[
				'label' => __( 'Post Control', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'portpostperpage',
			[
				'label' => __( 'Post Per Page', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 999,
			]
        );
        $this->end_controls_section();
    }

	protected function render() {
        $settings = $this->get_settings_for_display();
        $porttitle = $settings['porttitle'];
        $portsubtitle = $settings['portsubtitle'];
        $portcontent = $settings['portcontent'];
        
        $portpostperpage =  $settings['portpostperpage'];


        $this->add_inline_editing_attributes('porttitle','basic');
        $this->add_inline_editing_attributes('portsubtitle','none');

        $this->add_inline_editing_attributes('portcontent','basic');

         $the_query = new WP_Query( array(
            'post_type' => 'portfolio',
            'posts_per_page' => $portpostperpage,
            'order' => 'ASC',
            ));
        ?>
<section class="projectewidget">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 mt-auto">
                <div class="home-portfolio text-center">
                <h5 <?php echo $this->get_render_attribute_string('porttitle');?>><?php echo esc_html($porttitle);?></h5>
                    <h2 <?php echo $this->get_render_attribute_string('portsubtitle');?>><?php echo esc_html($portsubtitle);?></h2>
                    <p <?php echo $this->get_render_attribute_string('portcontent');?>><?php echo esc_html($portcontent);?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="filtering">
        <ul>
        <?php
			$categories = get_categories('taxonomy=portfolio_category&post_type=portfolio'); ?>
            
            <li class="active" data-filter="*"><?php echo _e('All','cmoelementorwidgets');?></li>
	        <?php foreach ($categories as $category) : ?>
            <li  data-filter=".<?php echo esc_attr($category->slug); ?>"><?php echo esc_html($category->name); ?></li>
	        <?php endforeach; ?>
        </ul>
    </div>
    <div class="container">
        <div class="portfolio-item">
            <div class="row">
            <?php
            while($the_query->have_posts()): 
                $the_query->the_post();
                $terms = get_the_terms ($the_query->ID, 'portfolio_category');
                if ( !is_wp_error($terms) && !empty($terms)) : 
                $slugs = wp_list_pluck($terms, 'slug');

                $slug = implode(" ", $slugs);
            ?>
                <div class="col-md-4 item <?php echo esc_attr($slug);?>">
                <?php else: ?>
                <div class="col-md-4 item">
                <?php
                endif;
                ?>
                    <img src="<?php the_post_thumbnail_url('cmo-team-portfolio');?>" alt=""/>
                    <div class="img-content">
                        <a href="<?php the_permalink(); ?>"><i class="fa fa-link" aria-hidden="true"></i></a>
                        <h4><?php the_title(); ?></h4>
                    </div>
                </div>
                <?php
                endwhile;
                wp_reset_query();
                ?>
            </div>
        </div>
    </div>
</section>
        <?php
    }

	protected function _content_template() {}

}