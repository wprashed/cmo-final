<?php

class Elementor_CMOTestimonialvtwo_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'testimonialvtwo';
	}

	public function get_title() {
		return __( 'CMO: Testimonial v2', 'elementor' );
	}
	public function get_icon() {
        return 'far fa-comments';
    }

	public function get_categories() {
        return array('cmocategory');
    }
	protected function _register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Background

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'cmoelementorwidgets' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .testimonial-section',
			]
		);

		// Margin

		$this->add_control(
			'margin',
			[
				'label' => __( 'Margin', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .testimonial-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Padding

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .testimonial-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'testimonialttitle',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
		);
		$this->add_control(
			'testimonialsubtitle',
			[
				'label' => __( 'Subtitle', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Subtitle', 'cmoelementorwidgets' ),
			]
		);
		$this->end_controls_section();

		//for color
		$this->start_controls_section(
			'color_section',
			[
				'label' => __( 'Color', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'testimonialttitlecolor',
			[
				'label' => __( 'Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#737f9a',
                'selectors' => [
                    '{{WRAPPER}} .prot-head h6' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->add_control(
			'testimonialsubtitlecolor',
			[
				'label' => __( 'Subtitle Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} .prot-head h3' => 'color: {{VALUE}}'
                ]
			]
		);
		
		$this->end_controls_section();
		// post control
        $this->start_controls_section(
			'testimonial_post_control_section',
			[
				'label' => __( 'Post Control', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'testimonialpostperpage',
			[
				'label' => __( 'Post Per Page', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
			]
        );
        $this->add_control(
			'testimonialpostorderby',
			[
				'label' => __( 'Order By', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' =>'title',
				'options' => [
					'title'  => __( 'Title', 'cmoelementorwidgets' ),
					'date' => __( 'Date', 'cmoelementorwidgets' ),
                ],
			]
        );
        $this->add_control(
			'testimonialpostorder',
			[
				'label' => __( 'Order', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' =>'ASC',
				'options' => [
					'ASC'  => __( 'ASC', 'cmoelementorwidgets' ),
					'DESC' => __( 'DESC', 'cmoelementorwidgets' ),
                ],
			]
        );
        $this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$testimonialttitle = $settings['testimonialttitle'];
		$testimonialsubtitle = $settings['testimonialsubtitle'];

		//for post control
		$testimonialpostperpage = $settings['testimonialpostperpage'];
        $testimonialpostorderby = $settings['testimonialpostorderby'];
        $testimonialpostorder = $settings['testimonialpostorder'];

		// for inline editing
		$this->add_inline_editing_attributes('testimonialttitle','none');
		$this->add_inline_editing_attributes('testimonialsubtitle','none');

        $the_query = new WP_Query( array(
            'post_type' => 'testimonial',
            'posts_per_page' => $testimonialpostperpage,
            'orderby' => $testimonialpostorderby,
            'order' => $testimonialpostorder
        ));
		?>
<!--testimonial-section-start-->
<section class="testimonial-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-12 col-xm-12 mx-auto">
                <div class="prot-head text-center">
					<h6 <?php echo $this->get_render_attribute_string('testimonialttitle');?>><?php echo esc_html($testimonialttitle);?></h6>
					<h3 <?php echo $this->get_render_attribute_string('testimonialsubtitle');?>><?php echo esc_html($testimonialsubtitle);?></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xm-12">
                <div class="testimonial-img-slider owl-carousel owl-theme">
                    <div class="item">
                        <div class="row">
						<?php if($the_query->have_posts()):
					while($the_query->have_posts()): $the_query->the_post(); ?>
                            <div class="col-sm-6">
                                <!--Avator-description-start-->
                                <div class="single-item">
                                    <div class="avator-img">
                                        <img src="<?php echo esc_url(get_post_meta(get_the_ID(),'_cmo_photo', true)); ?>" alt="Avator"/>
                                    </div>
                                    <div class="avator_content">
                                        <div class="quote_img">
                                            <i class="fa fa-quote-right fa-5x"></i>
                                        </div>
                                        <div class="avator-text">
										<p><?php echo wp_kses_post(get_post_meta(get_the_ID(),'_cmo_testimonial_details', true)); ?></p>
                                        </div>
                                    </div>
                                    <div class="avator-title">
                                        <h3><?php the_title();?></h3>
                                    </div>
                                    <div class="desination">
                                        <p><?php echo esc_html(get_post_meta(get_the_ID(),'_cmo_designation', true)); ?></p>
                                    </div>
                                </div><!--Avator-description-end-->
                            </div>
							<?php 
								endwhile;
								endif;
								wp_reset_query();
								?>
                        </div>
                    </div>
					<div class="item">
                        <div class="row">
						<?php if($the_query->have_posts()):
					while($the_query->have_posts()): $the_query->the_post(); ?>
                            <div class="col-sm-6">
                                <!--Avator-description-start-->
                                <div class="single-item">
                                    <div class="avator-img">
                                        <img src="<?php echo esc_url(get_post_meta(get_the_ID(),'_cmo_photo', true)); ?>" alt="Avator"/>
                                    </div>
                                    <div class="avator_content">
                                        <div class="quote_img">
                                           <i class="fa fa-quote-right fa-5x"></i>
                                        </div>
                                        <div class="avator-text">
										<p><?php echo wp_kses_post(get_post_meta(get_the_ID(),'_cmo_testimonial_details', true)); ?></p>
                                        </div>
                                    </div>
                                    <div class="avator-title">
                                        <h3><?php the_title();?></h3>
                                    </div>
                                    <div class="desination">
                                        <p><?php echo esc_html(get_post_meta(get_the_ID(),'_cmo_designation', true)); ?></p>
                                    </div>
                                </div><!--Avator-description-end-->
                            </div>
							<?php 
								endwhile;
								endif;
								wp_reset_query();
								?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!--testimonial-section-end-->
		<?php
	}

	protected function _content_template() {
	
	}
}