<?php

class Elementor_CMOSevicetow_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'listservice';
	}

	public function get_title() {
		return __( 'CMO: Servie v2', 'elementor' );
	}
	public function get_icon() {
        return 'fas fa-suitcase-rolling';
    }

	public function get_categories() {
        return array('cmocategory');
    }
	protected function _register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Background

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'cmoelementorwidgets' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .service01',
			]
		);

		// Margin

		$this->add_control(
			'margin',
			[
				'label' => __( 'Margin', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .service01' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Padding

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .service01' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'sertwottitle',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
		);
		$this->add_control(
			'sertwosubtitle',
			[
				'label' => __( 'Subtitle', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Subtitle', 'cmoelementorwidgets' ),
			]
		);
		$this->add_control(
			'sertwocontent',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Content', 'cmoelementorwidgets' ),
			]
        );
		$this->end_controls_section();


		//repeater
		$this->start_controls_section(
			'list_section',
			[
				'label' => __( 'Item Details', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'list_title', [
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'List Title', 'cmoelementorwidgets' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'list_content', [
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'List Content', 'cmoelementorwidgets' ),
				'show_label' => false,
			]
		);

		$repeater->add_control(
			'list_icon',
			[
				'label' => __( 'Icon', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'default' => 'fa fa-cogs',
			]
		);

		$this->add_control(
			'list',
			[
				'label' => __( 'Repeater List', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => __( 'List Title ', 'cmoelementorwidgets' ),
						'list_content' => __( 'List Content', 'cmoelementorwidgets' ),
					],
					
				],
				'title_field' => '{{{ list_title }}}',
			]
		);

		$this->end_controls_section();

		// for All Service button
		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Button', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sertwobtn',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
		);
		$this->add_control(
			'sertwobtnlink',
			[
				'label' => __( 'Url', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://example.com', 'cmoelementorwidgets' ),
			]
		);
		$this->end_controls_section();

		//for color
		$this->start_controls_section(
			'color_section',
			[
				'label' => __( 'Color', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'sertwottitlecolor',
			[
				'label' => __( 'Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#737f9a',
                'selectors' => [
                    '{{WRAPPER}} .prot-head h6' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->add_control(
			'sertwosubtitlecolor',
			[
				'label' => __( 'Subtitle Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} .prot-head h3' => 'color: {{VALUE}}'
                ]
			]
		);
		$this->add_control(
			'sertwocontentcolor',
			[
				'label' => __( 'Content Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#737f9a',
                'selectors' => [
                    '{{WRAPPER}} .prot-head p' => 'color: {{VALUE}}'
                ]
			]
		);
		$this->add_control(
			'sertwoitemiconcolor',
			[
				'label' => __( 'Item Icon Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#228AE6',
                'selectors' => [
                    '{{WRAPPER}} .ser-img i' => 'color: {{VALUE}}',
                ]
			]
		);
		$this->add_control(
			'sertwoitemcolor',
			[
				'label' => __( 'Item Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} .ser-text h6' => 'color: {{VALUE}}',
                ]
			]
		);
		$this->add_control(
			'sertwoitemconcolor',
			[
				'label' => __( 'Item Content Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#737f9a',
                'selectors' => [
                    '{{WRAPPER}} .ser-text p' => 'color: {{VALUE}}',
                ]
			]
        );

        $this->add_control(
			'sertwobuttoncolor',
			[
				'label' => __( 'Button Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} a.btn' => 'color: {{VALUE}}',
                ]
			]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'sertwobuttonbg',
				'label' => __( 'Button Background', 'cmoelementorwidgets' ),
				'types' => [ 'gradient'],
                'selector' => '{{WRAPPER}} a.btn',
			]
		);
        $this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$sertwottitle = $settings['sertwottitle'];
		$sertwosubtitle = $settings['sertwosubtitle'];
		$sertwocontent = $settings['sertwocontent'];

		// for repeater value
		$list =$settings['list'];

		//for button
		$sertwobtn = $settings['sertwobtn'];
		$sertwobtnlink = $settings['sertwobtnlink']['url'];

		// for inline editing
		$this->add_inline_editing_attributes('sertwottitle','none');
		$this->add_inline_editing_attributes('sertwosubtitle','none');
		$this->add_inline_editing_attributes('sertwocontent','none');
		$this->add_inline_editing_attributes('sertwobtn','none');
		$this->add_render_attribute('sertwobtn',[
            'class' => "btn"
        ]);
		?>
		<!--Service Area Start-->
<section id="service01">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="prot-head text-center">
                    <h6 <?php echo $this->get_render_attribute_string('sertwottitle');?>><?php echo esc_html($sertwottitle);?></h6>
                    <h3 <?php echo $this->get_render_attribute_string('sertwosubtitle');?>><?php echo esc_html($sertwosubtitle);?></h3>
                    <p <?php echo $this->get_render_attribute_string('sertwocontent');?>><?php echo esc_html($sertwocontent);?></p>
                </div>
            </div>
        </div>
        <div class="row">
		<?php
		if ( $list ) {
			foreach (  $list as $item ) {
		?>
            <div class="col-md-4 elementor-repeater-item-<?php echo esc_html($item['_id']);?>">
                <div class="service-item text-center">
                    <div class="ser-img">
                        <i class="<?php echo $item['list_icon'] ?> fa-3x"></i>
                    </div>
                    <div class="ser-text">
                        <h6><?php echo esc_html($item['list_title']);?></h6>
                        <p><?php echo wp_kses_post($item['list_content']);?></p>
                    </div>
                </div>
            </div>
			<?php 
			}
			}
			?>
        </div>
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="banner-area-btn">
                    <a <?php echo $this->get_render_attribute_string('sertwobtn');?> href="<?php echo esc_url($sertwobtnlink);?>"><?php echo esc_html($sertwobtn);?></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Service Area End-->

		<?php
	}

	protected function _content_template() {
	
	}
}