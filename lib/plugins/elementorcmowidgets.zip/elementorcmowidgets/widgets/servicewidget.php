<?php
class Elementor_CMO_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return "Service post";
    }

	public function get_title() {
        return __('CMO: Service v1','cmoelementorwidgets');
    }

	public function get_icon() {
        return 'fab fa-elementor';
    }

	public function get_categories() {
        return array('cmocategory');
    }

	protected function _register_controls() {
        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        // Background

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => __( 'Background', 'cmoelementorwidgets' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .business-passion',
            ]
        );

        // Margin

        $this->add_control(
            'margin',
            [
                'label' => __( 'Margin', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .business-passion' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Padding

        $this->add_control(
            'padding',
            [
                'label' => __( 'Padding', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .business-passion' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
			'servicetitle',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'type service title', 'cmoelementorwidgets' ),
			]
        );
        
        $this->add_control(
			'servicesubtitle',
			[
				'label' => __( 'subtitle', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'type service subtitle', 'cmoelementorwidgets' ),
			]
        );

        $this->add_control(
            'servicecontent',
            [
                'label' => __( 'Content', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'placeholder' => __( 'type service content', 'cmoelementorwidgets' ),
            ]
        );

        $this->add_control(
			'servicebutton',
			[
				'label' => __( 'Button Label', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'More Info',
				// 'placeholder' => __( 'type service subtitle', 'cmoelementorwidgets' ),
			]
        );
        $this->add_control(
			'servicebuttonurl',
			[
				'label' => __( 'Button Link', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'cmoelementorwidgets' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
        );
        $this->end_controls_section();

        $this->start_controls_section(
			'position_section',
			[
				'label' => __( 'Position', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'servicetitlealigment',
			[
				'label' => __( 'Title Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} h6.what-title' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->add_control(
			'servicesubtitlealigment',
			[
				'label' => __( 'Subtitle Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} h3.what-subtitle' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->add_control(
			'servicebuttonaligment',
			[
				'label' => __( 'Button Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} div.business-area-btn' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'color_section',
			[
				'label' => __( 'Color', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'servicetitlecolor',
			[
				'label' => __( 'Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} h6.what-title' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->add_control(
			'servicesubtitlecolor',
			[
				'label' => __( 'Subtitle Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} h3.what-subtitle' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->add_control(
			'servicebuttoncolor',
			[
				'label' => __( 'Button Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} a.btn' => 'color: {{VALUE}}',
                ]
			]
        );
        $this->add_control(
			'servicebuttonbg',
			[
				'label' => __( 'Button Backgound', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ff5e14',
                'selectors' => [
                    '{{WRAPPER}} a.btn' => 'background: {{VALUE}}',
                ]
			]
        );
        $this->end_controls_section();

        // post control
        $this->start_controls_section(
			'servic_post_control_section',
			[
				'label' => __( 'Post Control', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'servicepostperpage',
			[
				'label' => __( 'Post Per Page', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5,
			]
        );
        $this->add_control(
			'servicepostorderby',
			[
				'label' => __( 'Order By', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' =>'title',
				'options' => [
					'title'  => __( 'Title', 'cmoelementorwidgets' ),
					'date' => __( 'Date', 'cmoelementorwidgets' ),
                ],
			]
        );
        $this->add_control(
			'servicepostorder',
			[
				'label' => __( 'Order', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' =>'ASC',
				'options' => [
					'ASC'  => __( 'ASC', 'cmoelementorwidgets' ),
					'DESC' => __( 'DESC', 'cmoelementorwidgets' ),
                ],
			]
        );
        $this->end_controls_section();

        // grid control
        $this->start_controls_section(
			'grid_section',
			[
				'label' => __( 'Grid', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'columnnumber',
			[
				'label' => __( 'Column', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 12,
				'step' => 1,
				'default' => 4,
			]
		);

		$this->end_controls_section();
    }

	protected function render() {
        $settings = $this->get_settings_for_display();
        $servicetitle = $settings['servicetitle'];
        $servicesubtitle = $settings['servicesubtitle'];
        $servicecontent = $settings['servicecontent'];
        $servicetitlealigment =  $settings['servicetitlealigment'];
        $servicesubtitlealigment =  $settings['servicesubtitlealigment'];
        $servicebutton =  $settings['servicebutton'];
        $target = $settings['servicebuttonurl']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['servicebuttonurl']['nofollow'] ? ' rel="nofollow"' : '';
        $servicebuttonurl =  $settings['servicebuttonurl']['url'];
        
        //post control
        $servicepostperpage =  $settings['servicepostperpage'];
        $servicepostorderby =  $settings['servicepostorderby'];
        $servicepostorder =  $settings['servicepostorder'];

        //grid
        $column = $settings['columnnumber'];

        $this->add_inline_editing_attributes('servicetitle','basic');
        $this->add_render_attribute('servicetitle',[
            'class' => "what-title"
        ]);
        $this->add_inline_editing_attributes('servicesubtitle','none');
        $this->add_render_attribute('servicesubtitle',[
            'class' => "what-subtitle"
        ]);

        $this->add_inline_editing_attributes('servicebutton','basic');
        $this->add_render_attribute('servicebutton',[
            'class' => "btn"
        ]);
        ?>
        <!--start-trusted-business-partner-->
<section class="business-passion">
    <div class="container">
        <!--start-business-content-->
        <div class="business-content">
            <div class="row">
                <div class="col-md-<?php echo esc_html($column);?>">
                    <div class="what-we-text">
                        <h6 <?php echo $this->get_render_attribute_string('servicetitle');?>><?php echo esc_html($servicetitle);?></h6>
                        <h3 <?php echo $this->get_render_attribute_string('servicesubtitle');?>><?php echo esc_html($servicesubtitle);?></h3>
                        <p <?php echo $this->get_render_attribute_string('servicecontent');?>><?php echo esc_html($servicecontent);?></p>
                        <div class="business-area-btn">
                            <a <?php echo $this->get_render_attribute_string('servicebutton');?> href="<?php echo esc_url($servicebuttonurl);?>" <?php echo $target; echo $nofollow; ?>><?php echo esc_html($servicebutton);?></a>
                        </div>
                    </div>
                </div>
                <?php $the_query = new WP_Query( array(
                        'post_type' => 'service',
                        'posts_per_page' => $servicepostperpage,
                        'orderby' => $servicepostorderby,
                        'order' => $servicepostorder
                    ));
                    ?>
                    <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
                    <div class="col-md-<?php echo esc_html($column);?>">
                        <div class="busn-img">
                            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                            <div class="busn-text text-center">

                                <h5 class="bu-con"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                <p><?php the_excerpt(); ?></p>
                                <div class="bu-angle-icon">
                                    <a href="<?php the_permalink(); ?>"><i class="fa fa-angle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
            <?php endwhile; ?>
            <?php wp_reset_query(); ?>
            </div><!--End-Col-->
        </div><!--end-business-content-->
        <!--end-who-we-are-->
    </div><!--end-container-->
</section><!--end-trusted-business-partner-->
        <?php
    }

	protected function _content_template() {}

}