<?php
class Elementor_CMOCase_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return "case";
    }

	public function get_title() {
        return __('CMO: Case Slider','cmoelementorwidgets');
    }

	public function get_icon() {
        return 'fa fa-slideshare';
    }

	public function get_categories() {
        return array('cmocategory');
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        // Background

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => __( 'Background', 'cmoelementorwidgets' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .problem-solution-section',
            ]
        );

        // Margin

        $this->add_control(
            'margin',
            [
                'label' => __( 'Margin', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .problem-solution-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Padding

        $this->add_control(
            'padding',
            [
                'label' => __( 'Padding', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .problem-solution-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
			'casetitle',
			[
				'label' => __( 'Title', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Title', 'cmoelementorwidgets' ),
			]
        );
        
        $this->add_control(
			'casesubtitle',
			[
				'label' => __( 'subtitle', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'subtitle', 'cmoelementorwidgets' ),
			]
        );
        $this->add_control(
			'casecontent',
			[
				'label' => __( 'Content', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Type something', 'cmoelementorwidgets' ),
			]
        );

        $this->end_controls_section();
        
        //for position
        $this->start_controls_section(
			'position_section',
			[
				'label' => __( 'Position', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'casetitlealigment',
			[
				'label' => __( 'Title Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'center',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .prot-head h6' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->add_control(
			'casesubtitlealigment',
			[
				'label' => __( 'Subtitle Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'center',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .prot-head h3' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->add_control(
			'casecontentaligment',
			[
				'label' => __( 'Subtitle Aligment', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'center',
				'options' => [
					'center'  => __( 'Center', 'cmoelementorwidgets' ),
					'left' => __( 'Left', 'cmoelementorwidgets' ),
					'right' => __( 'Right', 'cmoelementorwidgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .prot-head p' => 'text-align: {{VALUE}}'
                ]
			]
        );

        $this->end_controls_section();

        //for color
		$this->start_controls_section(
			'color_section',
			[
				'label' => __( 'Color', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'casettitlecolor',
			[
				'label' => __( 'Title Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#bfc5cf',
                'selectors' => [
                    '{{WRAPPER}} .prot-head h6' => 'color: {{VALUE}}'
                ]
			]
        );
        $this->add_control(
			'casesubtitlecolor',
			[
				'label' => __( 'Subtitle Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#333b4c',
                'selectors' => [
                    '{{WRAPPER}} .prot-head h3' => 'color: {{VALUE}}'
                ]
			]
		);
		$this->add_control(
			'casecontentcolor',
			[
				'label' => __( 'Content Color', 'cmoelementorwidgets' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#8f9bb5',
                'selectors' => [
                    '{{WRAPPER}} .prot-head p' => 'color: {{VALUE}}'
                ]
			]
		);
		
        $this->end_controls_section();

        // post control
        $this->start_controls_section(
			'case_post_control_section',
			[
				'label' => __( 'Post Control', 'cmoelementorwidgets' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'casepostperpage',
			[
				'label' => __( 'Post Per Page', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5,
			]
        );
        $this->add_control(
			'casepostorderby',
			[
				'label' => __( 'Order By', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' =>'title',
				'options' => [
					'title'  => __( 'Title', 'cmoelementorwidgets' ),
					'date' => __( 'Date', 'cmoelementorwidgets' ),
                ],
			]
        );
        $this->add_control(
			'caseepostorder',
			[
				'label' => __( 'Order', 'cmoelementorwidgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' =>'ASC',
				'options' => [
					'ASC'  => __( 'ASC', 'cmoelementorwidgets' ),
					'DESC' => __( 'DESC', 'cmoelementorwidgets' ),
                ],
			]
        );
        $this->end_controls_section();

    }

	protected function render() {
        $settings = $this->get_settings_for_display();
        $casetitle = $settings['casetitle'];
        $casesubtitle = $settings['casesubtitle'];
        $casecontent = $settings['casecontent'];

        $casepostperpage = $settings['casepostperpage'];
        $casepostorderby = $settings['casepostorderby'];
        $caseepostorder = $settings['caseepostorder'];


        // for inline editing
        $this->add_inline_editing_attributes('casetitle','none');
		$this->add_inline_editing_attributes('casesubtitle','none');
        $this->add_inline_editing_attributes('casecontent','none');
        
        $the_query = new WP_Query( array(
            'post_type' => 'case_study',
            'posts_per_page' => $casepostperpage,
            'orderby' => $casepostorderby,
            'order' => $caseepostorder
        ));
       ?>
<!--Case Study start-->
<section class="problem-solution-section">
    <div class="container">
        <div class="end-solution-section">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-8 col-xm-8 mx-auto">
                    <div class="prot-head text-center">
                        <h6 <?php echo $this->get_render_attribute_string('casetitle');?>><?php echo esc_html($casetitle);?></h6>
                        <h3 <?php echo $this->get_render_attribute_string('casesubtitle');?>><?php echo esc_html($casesubtitle);?></h3>
                        <p <?php echo $this->get_render_attribute_string('casecontent');?>><?php echo esc_html($casecontent);?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xm-12">
                    <!--start-problem-and-solution-section-->
                    <div class="ps-slider">
                        <div class="home2-testimonial owl-carousel owl-theme">
                     <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
                            <div class="item">
                                <div class="slider-img">
                                    <?php the_post_thumbnail('cmo-case-lanscape');?>
                                </div>
                                <div class="carousel-caption">
                                <?php
                                $args = array('number' => '3',);
                                $terms = get_terms('case_category', $args );
                                  foreach( $terms as $term ){
                                  echo '<span>' . esc_html($term->name) . '  </span>';
                                  } 
                                ?>
                                    <a href="<?php the_permalink();?>"><h5><?php the_title();?></h5></a>
                                    <p><?php the_excerpt();?></p>
                                    <div class="prot-area-btn">
                                        <div class="btn"><a href="<?php the_permalink();?>"><?php _e('READ MORE','cmoelementorwidgets')?></a></div>
                                    </div>
                                </div>
                            </div>
                            <?php
                            endwhile;
                            wp_reset_query();
                            ?>
                        </div>
                    </div><!--end-problem-and-solution-section-->
                </div>
            </div>
        </div>
    </div>
    <!--end-container-->
</section><!--Case-Study-end-->

       <?php
    }

	protected function _content_template() {}

}